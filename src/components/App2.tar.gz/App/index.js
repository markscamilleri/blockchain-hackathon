import React, { Component } from 'react';
import logo from './Identity.png';
import './style.css';

class App extends Component {
    render() {
        return (
            <div className="App">
                <div className="App-header">
                    <img src={logo} className="App-logo" alt="logo" />
                    <h2>Identity Manager</h2>
                </div>
                <div align="center" className="App-nav">

                    <form id="input" action="/action_page.php">
                        <table>
                            <tr>
                                <th>First name:  </th>
                                <th><input type="text" name="fname"></input></th>
                            </tr>
                            <tr>
                                <th>Last name: </th>

                                <th><input type="text" name="lname"></input></th>
                            </tr>
                            <tr>
                                <th> ID No.:  </th>
                                <th><input type="text" name="ID"></input></th>
                            </tr>
                            <tr>
                                <th> Nationality:</th>
                                <th> <input type="text" name="nationality"></input></th>
                            </tr>
                            <tr>
                                <th> Locality: </th>
                                <th> <input type="text" name="locality"></input></th>
                            </tr>
                            <tr>
                                <th> Sex: </th>
                                <th> <input type="text" name="sex"></input></th>
                            </tr>
                        </table>
                        <input id="submission" className="buttonSubmit" type="button" value="Create Identity"></input>
                    </form>

  <form id="revoke" className="revokeField" action="/action_page.php">
                        <table>
                            <tr>
                                <th>Revoke ID</th>
                                <th><input type="text" name="revID"></input></th>
                            </tr>
                        </table>
                        <input id="submissionRev" className="buttonSubmit" type="button" value="Revoke"></input>
                    </form>
                </div>
            </div>
        );
    }
}

window.onload = function () {
    document.getElementById("submission").onclick = function fun() {
        
        //create identity
        exportToContract();
    }
    document.getElementById("submissionRev").onclick = function func() {    
        //revoke identity
    }
}

function exportToContract() {
    var Web3 = require('web3');
    var web3;

    if (!web3) {
//Connect to web3 instance
        web3 = new Web3(new Web3.providers.HttpProvider('http://localhost:8545'));
    }

       
    //Copy abi into a json file and put it somewhere within nodejs app folder somewhere
    //var abiJson = require('./Storage.json');
    //Copy your contract address here
    var contAddr = "0xf3f9eb3b8ce4f2e054914e4789ca74869b34a126";
    var bcHelper = require('./bcHelper.js');
    
    var fname = document.forms["input"]["fname"].value;
    var lname = document.forms["input"]["lname"].value;
    var ID = document.forms["input"]["ID"].value;
    var nationality = document.forms["input"]["nationality"].value;
    var locality = document.forms["input"]["locality"].value;
    var sex = document.forms["input"]["sex"].value;

    if (!(fname != null && lname != null && nationality != null && locality != null && sex != null)) {
        alert("Fields must be filled out");
        return false;
    }
    var storageContract = new web3.eth.Contract([{"constant":false,"inputs":[{"name":"data","type":"uint256"}],"name":"set","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"get","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"}]);
  
    storageContract.options.address =contAddr;
   storageContract.methods.set(500).send({from:"0x01e7d1d05602cd9cf08a41572de20669f884ad9f"}).then(result=>{
    var output = storageContract.methods.get().call().then(console.log);
    console.log(output);
   })

   //var output = storageContract.methods.get().toString();
   var output = storageContract.methods.get().call().then(console.log);
   console.log(output);
//do contractref.[func] of smart contract
}
export default App;
